package test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class AddDebugInfo {

    private int fileIndex = 0;

    public AddDebugInfo() {}

    // Caller will pass 4 params to us: apkPath, patchPath, decodePath, param
    public void addDebugInfo(String apkPath, String patchPath, String decodePath, String param) throws IOException {
        String subPath = param;

        File rootDir = new File(decodePath);

        String paths[] = subPath.split("/");
        for (String path : paths) {
            if (!"".equals(path)) {
                rootDir = new File(rootDir, path);
            }
        }

        addDebugInfo(rootDir);
    }

    private void addDebugInfo(File dir) {
        File files[] = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    addDebugInfo(file);
                } else if (file.isFile()) {
                    addDebugInfo(file, true);
                }
            }
        }
    }

    private void addDebugInfo(File file, boolean notused) {
        String pattern1 = "\\.line \\d+";
        String pattern2 = "\\.source (.+)";

        try {
            //Read data from file
            String stringContents = readDataFromFile(file);

            //Remove .line
            stringContents = stringContents.replaceAll(pattern1, "");

            //Remove .source if exist
            stringContents = stringContents.replaceAll(pattern2, "");

            //Add .source "DebugFile_(Number)"
            stringContents = stringContents.replaceAll("\\.super (.+)\\n", ".super $1 \n.source \"DebugFile_" + Integer.toString(fileIndex++) + "\"\n");

            //Add lines to smali code
            stringContents = AddLinesToSmali(stringContents);

            //Save result to file
            writeDataToFile(file, stringContents);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String readDataFromFile(final File file) {
        BufferedReader br = null;
        StringBuilder result = new StringBuilder();

        try {
            br = new BufferedReader(new FileReader(file));

            while (br.ready()) {
                result.append(br.readLine());
                result.append(System.getProperty("line.separator"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            closeQuietly(br);
        }

        return result.toString();
    }

    private static void closeQuietly(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException ignored) {
            }
        }
    }

    private static boolean writeDataToFile(File file, String data) {
        BufferedWriter bw = null;
        boolean ret = false;

        try {
            bw = new BufferedWriter(new FileWriter(file));
            bw.write(data);
            ret = true;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            closeQuietly(bw);
        }

        return ret;
    }

    private static String AddLinesToSmali(final String content) {
        int i = 0;

        String[] lines = content.split(System.getProperty("line.separator"));
        StringBuilder result = new StringBuilder();

        Boolean do_insert = true;
        Boolean in_metod = false;

        int addedLines = 0;
        for (String line : lines) {
            i += 1;

            if (line.trim().length() < 2) {
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".method")) {
                in_metod = true;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".end method")) {
                in_metod = false;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".packed-switch")) {
                do_insert = false;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".end packed-switch")) {
                do_insert = true;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".array-data")) {
                do_insert = false;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".end array-data")) {
                do_insert = true;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".sparse-switch")) {
                do_insert = false;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".end sparse-switch")) {
                do_insert = true;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".annotation")) {
                do_insert = false;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".end annotation")) {
                do_insert = true;
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(".")) {
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (line.trim().startsWith(":")) {
                result.append(line).append(System.getProperty("line.separator"));
                continue;
            }
            if (in_metod) {
                if (do_insert) {
                    result.append("    .line ").append(Integer.toString(i + addedLines)).append(System.getProperty("line.separator"));
                    result.append(line).append(System.getProperty("line.separator"));
                    addedLines += 1;
                } else {
                    result.append(line).append(System.getProperty("line.separator"));
                }
            } else {
                result.append(line).append(System.getProperty("line.separator"));
            }
        }

        return result.toString();
    }
}
